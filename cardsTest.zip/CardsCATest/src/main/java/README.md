# CardsCA
Using Maven enter the command mvn compile followed by mvn clean
After this all that is needed to be done is enter mvn test and you will be able to run all the tests specified in the test suite!
The files are organised and coded so that maven can easily access all the test classes and run all tests. 