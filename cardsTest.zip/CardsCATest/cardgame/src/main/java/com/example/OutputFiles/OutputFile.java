package OutputFiles;
import java.io.File;
import java.io.IOException;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.time.LocalDateTime;
import java.time.format.*;

/**
 * Class for the output files of the games so that games can be saved and details about what happened in each game is stored.
 */
public class OutputFile {
    public int numOfPlayers;

    public OutputFile(int numOfPlayers) {
        this.numOfPlayers = numOfPlayers;
    }

    /**
     * Create folder function creates a folder based on the date month year and time of day so that for every game played only one folder
     * will exist for that game and the player can find the game they are looking for based on the time. 
     * @return folder path and name so that it can be used by threads for entering data.
     * @throws IOException
     */
    public String createFolder() throws IOException {
        LocalDateTime currentTime = LocalDateTime.now();
        DateTimeFormatter format = DateTimeFormatter.ofPattern("dd/MM/yy:HH:mm:SS");
        String formattedDateTime = currentTime.format(format);

        String folderPath = "src/main/java/OutPutFiles/";
        String folderName = "GamePlayed=" + formattedDateTime.replace("/",".").replace(":","_");

        File folder = new File(folderPath+folderName);
        folder.mkdir();
        createOutputFile(folder);

        return folderPath+folderName;

    }

    /**
     * Creates an output file for each player thread. This is done so data about each players game actions can be stored and viewed by anyone
     * @param folder takes in the folder of the game so that it can save each players file to that folder
     * @throws IOException
     */
    public void createOutputFile(File folder) throws IOException {

        for (int i = 1; i < numOfPlayers + 1; i++) {
            File newFile = new File(folder,"player" + i + "_output.txt");
            newFile.createNewFile();
        }
    }

}



