import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import OutputFiles.OutputFile;

import java.util.Scanner;

public class Player implements Runnable {

    private int playerID;
    private List<Integer> hand;
    private List<List<Integer>> packs;
    private String folder;

    public AtomicBoolean gameWon = new AtomicBoolean(false);
    public AtomicInteger playerIDWon = new AtomicInteger(0);
    
    /**
     * Constructor for player class. This class is where the game will run for each player thread when started as well as other game ending checks.
     * Once started the CardGame file will send all necessary data into here for the threads to start running the game.
     * @param playerID Player number of each player eg player4
     * @param hand The 4 or 5 current cards the player is holding depending on their state in the game
     * @param packs All of the packs that are inbetween players during the game
     * @param gameWon If the game is won then the loop of this thread will end since the game is over
     * @param playerIDWon The ID of the player who won the game so they can inform the other players they won.
     * @param foldername The name of the folder of the current game so info can be added into the exact player file they need
     */
    public Player(int playerID,List<Integer> hand, List<List<Integer>> packs , AtomicBoolean gameWon,AtomicInteger playerIDWon, String foldername) {
        this.playerID = playerID;
        this.hand = hand;
        this.packs = packs;
        this.gameWon = gameWon;
        this.playerIDWon = playerIDWon;
        this.folder = foldername;


    }


    /**
     * Checks a players hand at the start of the game to check for an instant win. 
     * @return True if instant win false if not.
     */
    protected boolean isInstantWin() {
        int preferredCards = playerID;
        int correctCount = 0;
        int allSameValCount = 0;
        int firstCardVal = hand.get(0);

        for (int i = 0; i<hand.size();i++) {
            if (playerID == hand.get(i)) {
                correctCount++;
            }
        }

        for (int i=1; i<hand.size(); i++) {
            if (hand.get(i) == firstCardVal) {
                allSameValCount++;
            }
        }


        if (correctCount == 4 || allSameValCount ==3) {
            return true;
        } else {
            return false;
        }

    }

    /**
     * Checks if a players hand is eligible for a win condition where the player has 4 of the same cards along with it being the same value
     * as the playerID so player 1 needs 1 1 1 1
     * @return true if win condition met or false if not
     */
    protected boolean isWin() {
        int preferedCardVal = playerID;
        int cardCount = 0;

        for (int card : hand) {
            if (card == preferedCardVal) {
                cardCount++;
            }
        }

        if (cardCount == 4 && hand.size() == 4) {
            return true;
        } else {
            return false;
        }

    }



    /**
     * Each thread is run in this method. From the start it identifies which file it needs to write game info to and checks if instant win is met
     * After that it runs the cycle of taking a card from the left choosing a bad card and discarding it to the right until the player either wins
     * or someone wins the game first.
     * Returns back to main game once the atomic boolean value is met.
     */
    @Override
    public void run() {
        String playersFileName = "player" + playerID + "_output.txt";

        File playerFile = new File(folder,playersFileName);


        
        
        if (isInstantWin()) {
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile))) {
                writer.write("Player " + playerID + " wins instantly with hand: " + hand.toString());
                writer.write("\n");
            } catch (IOException e) {
                e.printStackTrace();
            }
            playerIDWon.set(playerID);
            gameWon.set(true);
            return;
            
        }
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile , true))) {
            writer.write("player " + playerID + " intial hand " + hand.toString());
            writer.write("\n");
        } catch (IOException e) {
            e.printStackTrace();
        }
        
        
        while (!gameWon.get()) {
            int leftPackIndex = 0;
            int rightPackIndex = 0;
            if (playerID == 1) {
                leftPackIndex = packs.size() - 1;
                rightPackIndex = 0;
            } else { 
                leftPackIndex = playerID -2;
                rightPackIndex = playerID-1;

            }
            
            //Synchronised the packs in the game so there arent any inconsistencies. after this it then makes sure when taking a card from the left pack it isnt empty and the hand size of the player is 4
            //Once this is checked it writes the card taken to the file and then discards a bad card if the hand size is 5 and there are less than 5 cards in the right pack
            //Then it notifies all threads to make sure synchronize all packs by notify all
            synchronized (packs) {
                if (!packs.get(leftPackIndex).isEmpty() && hand.size() == 4) {
                    int cardTaken = packs.get(leftPackIndex).remove(0);
                    hand.add(cardTaken);

                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile, true))) {
                        writer.write("Player " + playerID + " picks up card " + cardTaken + " from pack " + leftPackIndex + ". Current hand: " + hand.toString());
                        writer.write("\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }

                if (packs.get(rightPackIndex).size() < 5 && hand.size() == 5) {
                    int cardToDiscard = 0;

                    for (int i=0; i < hand.size();i++) {
                        if (hand.get(i) != playerID) {
                            cardToDiscard = hand.remove(i);
                            packs.get(rightPackIndex).add(cardToDiscard);
                            break;
                        }
                    }
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile, true))) {
                        writer.write("Player " + playerID + " discards card " + cardToDiscard + " to pack " + rightPackIndex + ". Current hand: " + hand.toString());
                        writer.write("\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                }
                packs.notifyAll();


            }
            

            
            

            //If the iswin condition is met then the while loop can be broken and the atomic variables can be set. 
            if (isWin()) {
                synchronized (gameWon) {
                    playerIDWon.set(playerID);
                    try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile , true))) {
                        writer.write("player " + playerID + " wins\nplayer " + playerID +" exits\nplayer " + playerID + " hand" +  hand.toString());
                        writer.write("\n");
                    } catch (IOException e) {
                        e.printStackTrace();
                    }
                    gameWon.set(true);
                    System.out.println("Player " + playerIDWon.get() + " has won!");
                    return;
                }
                
            } else if (playerIDWon.get() != 0) {

                synchronized (packs) {
                    while (hand.size() > 4) {
                        int cardToDiscard = hand.remove(hand.size() - 1);
                        packs.get(playerID - 1).add(cardToDiscard);
                    }
                }
                try (BufferedWriter writer = new BufferedWriter(new FileWriter(playerFile , true))) {
                    writer.write("player " + playerIDWon.get() + " has informed player "+ playerID + " that player " + playerIDWon.get() + " has won\nplayer " + playerID +" exits\nplayer " + playerID + " hand" +  hand.toString());
                    writer.write("\n");
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    } 
}   
        


        



    
