import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Deck class used for checking pack files decks to see if valid or not or to load cards into the game decks 
 */
public class Deck {
    
    private int numOfPlayers;
    private File packFile;

    /**
     * Constructor class using numofplayers and packfile
     * @param numOfPlayers the number of players in the game
     * @param packFile the name of the pack file to be used in game
     */
    public Deck(int numOfPlayers, File packFile) {
        this.numOfPlayers = numOfPlayers;
        this.packFile = packFile;
    }

    /**
     * Method to check if the pack given by a user is a valid pack to be used in the game. If the numbers arent right or there arent enough
     * cards in the pack then it wont be used and false will be returned. Uses Scanner to check the content of files when making sure
     * they are correct.
     * @return False if pack invalid, true if pack valid
     * @throws FileNotFoundException
     */
    public boolean checkPackFileValid() throws FileNotFoundException {
        int expectedLines = 8*numOfPlayers;
        int linecount = 0;

        try (Scanner scanner = new Scanner(packFile)) {
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine().trim();
                linecount++;

                if (!positiveInt(line)) {
                    System.out.println("Pack file given is invalid");
                    return false;
                }

            }
            if (linecount != expectedLines) {
                System.out.println("Pack file given is invalid");
                return false;
            }

            System.out.println("Pack file given is valid continuing...");
            return true;
        }
        
    }

    /**
     * Checks if the item from the given pack file on a line is a positive integer
     * @param linenum the item of data on a specific line in the pack file
     * @return true if its a positive int or false if its not.
     */
    public boolean positiveInt(String linenum) {
        try {
            int number = Integer.parseInt(linenum);
            return number > 0;
        
        } catch (NumberFormatException e) {
            return false;
        }
    }

    /**
     * Retrieves the pack file
     * @return the pack file
     */
    public File retrievePackFileForEnd() {
        return packFile;
    }


    /**
     * Method used to load the cards from a file into an array to be sent back to the main game. Once all checks are complete this method is used
     * with valid files only and the scanner will add all the cards into a pack array and send to the game. 
     * @return Cards to be used in the game.
     * @throws FileNotFoundException
     */
    public List<Integer> loadCards() throws FileNotFoundException {
        List<Integer> cards = new ArrayList<>();

        try (Scanner scanner = new Scanner(packFile)) {
            while (scanner.hasNextLine()) {
                cards.add(Integer.parseInt(scanner.nextLine().trim()));
            }
        }
        
        return cards;
        

    }
}
