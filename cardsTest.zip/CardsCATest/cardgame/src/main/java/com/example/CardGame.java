import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

import CardPacks.CardPackGen; 
import OutputFiles.OutputFile;


/**
 * The main game class where everything runs through. 
 * Starts by using a scanner object to take in the number of players in the game. It then does the necessary checks that the number of players
 * is usable for a game. Checks for the entry being an int, 2 or above etc.
 * Then is the system to take in a valid pack file. The user gets 3 options whether they want to give a designated file path, choose a pack file in the directory or get one generated for them. Only valid packs are allowed.
 * After this the multiple threads for players will be created after building the decks from the pack file and an executor will start running 
 * the multithreads so the game is going on concurrently. 
 * Once the atomic boolean variable isWon has been set to true the executor will end all threads and the game files will be saved so that 
 * the games information can be seen by the user. 
 */
public class CardGame {
    public static void main(String[] args) throws IOException {
        Scanner myObj = new Scanner(System.in);
        int numOfPlayers = 0;

        Deck deck = null;
        List<Integer> cards = null;

        while (true) {
            System.out.println("Enter number of players:");

            if (myObj.hasNextInt()) {
                numOfPlayers = myObj.nextInt();
                if (numOfPlayers > 1) {
                    break;
                } else {
                    System.out.println("Number of players must be a positive integer equal to or above 2");
                }
            } else {
                System.out.println("Invalid input please enter a valid integer");
                myObj.next();
            }
        }
        myObj.nextLine();
        
        //Up to this point the program has gotten a valid integer entry from the person running them game so it can commence with N players


        boolean fileFound = false;

        //Main game file entry loop, it asks for the file pack choice they want (so if they want to enter their own file or choose a pre made or generate a pack) and then
        // checks if the pack is valid or not. Game wont progress until valid. 
        while (!fileFound) {
            System.out.println("If you want to enter a pack from the directory enter 1\nIf you want to enter one from your files enter 2\nIf you want a custom generated pack for " + numOfPlayers + " enter 3");

            if (!myObj.hasNextInt()) {
                System.out.println("Invalid input please enter 1 2 or 3");
                myObj.next();
            }

            Integer packEntrySys = myObj.nextInt();
            myObj.nextLine();
            
            if (packEntrySys == 1) {
                while (true) {
                    System.out.println("Enter pack file in directory or enter 000 to go back");
                    String packLoc = myObj.nextLine();

                    if (packLoc.equals("000")) {
                        System.out.println("Returning...");
                        break;
                    }

                    File packFile = new File(packLoc);

                    if (!packFile.exists() || !packFile.isFile()) {
                        System.out.println("File not found please retry");
                    } else {
                        System.out.println("Pack found " + packLoc);
                        deck = new Deck(numOfPlayers, packFile);

                        if (!deck.checkPackFileValid()) {
                            System.out.println("Pack is invalid returing to menu...");
                            break;
                        } else {
                            fileFound = true;
                            break;
                        }
                        
                    }
                }
            } else if (packEntrySys == 2) {

                while (true) {
                    System.out.println("Enter full path for your pack file or enter 000 to go back");
                    String packLoc = myObj.nextLine();

                    if (packLoc.equals("000")) {
                        System.out.println("Going back...");
                        break;
                    }

                    File packFile = new File(packLoc);
                    if (!packFile.exists() || !packFile.isFile()) {
                        System.out.println("Pack file not found at the specified path. Please retry");
                    } else {
                        System.out.println("Pack file found at: " + packLoc);
                        deck = new Deck(numOfPlayers, packFile);
                        if (!deck.checkPackFileValid()) {
                            System.out.println("Pack file is invalid returning to main menu...");
                            break;
                        } else {
                            fileFound = true;
                            break;
                        }
                        
                    }

                }
            } else if (packEntrySys == 3) {
                System.out.println("Generating a pack for " + numOfPlayers + " players!");
                CardPackGen genCardPack = new CardPackGen(numOfPlayers);
                File packFile = genCardPack.createFile();
                deck = new Deck(numOfPlayers, packFile);

                if (packFile.exists() && packFile.isFile()) {
                    System.out.println("Pack made successfully!");
                    fileFound = true;
                    break;
                }
            } else {
                System.out.println("Enter a valid integer 1 2 or 3");
            }

            
        }
        


        

        
        
        



        
        //System to distribute players hands and also their decks to left and right

        System.out.println("Distributing cards to players...");
        cards = deck.loadCards();
        List<List<Integer>> playerCards = new ArrayList<>();
        List<List<Integer>> packs = new ArrayList<>();

        for (int i = 0; i < numOfPlayers; i++) {
            playerCards.add(new ArrayList<>());
            packs.add(new ArrayList<>());
        }

        

        Random random = new Random();

        for (int i=0;i < 4; i++) {
            for (int j=0; j < numOfPlayers; j++) {
                int randomIndex = random.nextInt(cards.size());
                playerCards.get(j).add(cards.remove(randomIndex));
            }
        }

        System.out.println("Cards given to players for starting hand");


        while (!cards.isEmpty()) {
            for (int i=0; i <numOfPlayers && !cards.isEmpty(); i++) {
                packs.get(i).add(cards.remove(0));
            }
        }




        //Atomic variables to make sure game doesnt go on infinitely
         
        AtomicBoolean gameWon = new AtomicBoolean(false);
        AtomicInteger playerIDWon = new AtomicInteger(0);
        

        //Multithreads being made and executed by using executor service

        ExecutorService executorService = Executors.newFixedThreadPool(numOfPlayers);
        OutputFile gameFolder = new OutputFile(numOfPlayers);
        String foldername = gameFolder.createFolder();

        for (int i = 0; i < numOfPlayers; i++) {
            Player player = new Player(i+1, playerCards.get(i), packs, gameWon, playerIDWon, foldername);
            executorService.submit(player);


        }

        
        executorService.shutdown();


    
       










      }
    }

