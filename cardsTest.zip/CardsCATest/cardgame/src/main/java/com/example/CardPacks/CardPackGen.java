package CardPacks;

import java.util.ArrayList;
import java.util.List;
import java.util.random.*;
import java.io.*;


/**
 * Card Pack gen class which is used when generating a dynamic pack. 
 * @return class generation returns different things depending on situation. 
 * @throws IOException If file not found
 */
public class CardPackGen {
    private Integer numofPlayers;
    private List<Integer> pack;

    /**
     * Constructor for class when object made of the class generatePack() is always called
     * @param numofPlayers The number of players in the game.
     */
    public CardPackGen(int numofPlayers) {
        this.numofPlayers = numofPlayers;
        this.pack = new ArrayList<>();
        generatePack();
        
    }

    /**
     * Used to generate the numbers for a specific pack that is needed when an invalid pack is given at the start of the game. Takes in the 
     * number of players that are in the game and creates 4 sets out of the 8 *N players. Overall is an array of valid numbers for the card game
     * stored in the this.pack. 
     */
    private void generatePack() {
        int sets = 4;

        for (int set = 0; set < sets; set++) {
            for (int i = 1; i < getPackRange(); i++) {
                this.pack.add(i);
            }
        }
    }

    /**
     * Get pack range gets the range of numbers that can be included in the pack so that a valid winner is guarenteed everytime and some extra cards
     * are added into the packs so there arent instant winners.
     * @return the number of players * 2 + 1 so that the boundaries for the for loop in pack generation works. 
     */
    private int getPackRange() {
        return numofPlayers * 2 + 1;
    }

    /**
     * Method to return the pack when called
     * @return the pack
     */
    public List<Integer> getPack() {
        return this.pack;
    }


    /**
     * Creates a file that can be used as a pack if needed for a card game. This is called if no valid pack is given at the start of the game
     * or no pack is entered by the user. The pathname is made to be somewhat random so that it is highly unlikely for duplicate card packs in the game
     * It then uses writer to add the numbers from the pack in the object into the file.
     * @return file object
     * @throws IOException 
     */
    public File createFile() throws IOException {
        File targetDir = new File("src/main/java/");
        File myObj = new File(targetDir,numofPlayers + ".txt");
        if (myObj.createNewFile()) {
            System.out.println("File created: " + myObj.getName());
        }

        FileWriter writer = new FileWriter(myObj);
        try {
            for (Integer card : pack) {
                writer.write(card.toString());
                writer.write("\n");
            }
        } catch (IOException e) {
            System.out.println("Error occured " + e.getMessage());
        } finally {
            writer.close();
        }
                return myObj;
    }



}
