import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.List;


public class TestDeck {
    private int numOfPlayers;
    private Deck deck;


    @BeforeEach
    void setUp() {
        numOfPlayers = 4;
        File packFile = new File("src\\test\\resources\\4.txt");
        deck = new Deck(numOfPlayers, packFile);

    }

    @Test
    void testCheckPackFileValid1() throws FileNotFoundException {
        boolean isValid = deck.checkPackFileValid();
        assertTrue(isValid,"The method should be true if pack is indeed valid");
        
    }

    @Test
    void testCheckPackFileValid2() throws Exception {
        File invPackFile = new File("src\\test\\resources\\testerFile1.txt");
        Deck deck2 = new Deck(numOfPlayers, invPackFile);
        boolean isValid = deck2.checkPackFileValid();
        assertFalse(isValid, "Negative integer in pack shouldnt be valid");

    }

    @Test
    void testPositiveInt() {
        String testnum = "10";
        boolean isValid = deck.positiveInt(testnum);
        assertTrue(isValid, "Number is positive");

    }

    @Test
    void testPositiveInt2() {
        String testnum = "-10";
        boolean isValid = deck.positiveInt(testnum);
        assertFalse(isValid, "Number isnt positive");

    }

    @Test
    void testPositiveInt3() {
        String testnum = "10.1";
        boolean isValid = deck.positiveInt(testnum);
        assertFalse(isValid, "Number is decimal");

    }

    @Test
    void testLoadCards1() throws FileNotFoundException {
        List<Integer> cards = deck.loadCards();
        boolean isValid = (cards.size() == 8*numOfPlayers); 
        assertTrue(isValid, "Should be valid if valid pack was given originally");
    }
    
}
