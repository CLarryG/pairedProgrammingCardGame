import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;


import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.util.List;

import java.util.ArrayList;

import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

public class TestPlayer {
    private Player player;
    private AtomicBoolean gameWon;
    private AtomicInteger playerIDWon;
    private List<Integer> hand;
    private List<List<Integer>> packs;

    
    

    @BeforeEach
    void setUp() {
        gameWon = new AtomicBoolean(false);
        playerIDWon = new AtomicInteger(0);
        hand = new ArrayList<>();
        hand.add(1);
        hand.add(2);
        hand.add(3);
        hand.add(4);

        packs = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            packs.add(new ArrayList<>());
        }

        player = new Player(1,hand,packs,gameWon,playerIDWon,"testFolder");
    }

    @Test
    void testIsInstaWin() {
        hand.clear();
        hand.add(1);
        hand.add(1);
        hand.add(1);
        hand.add(1);

        assertTrue(player.isInstantWin(), "player should win based off starting hand of same val");
    }

    @Test
    void testIsInstaWinFalse() {
        hand.clear();
        hand.add(1);
        hand.add(1);
        hand.add(2);
        hand.add(1);
        assertFalse(player.isInstantWin(),"not a winning starting hand should return false");
    }

    @Test
    void testIsWin() {
        hand.clear();
        hand.add(1);
        hand.add(1);
        hand.add(1);
        hand.add(1);

        assertTrue(player.isWin(), "player wins with all same val");

    }

    @Test
    void testIsWinFalse() {
        hand.clear();
        hand.add(1);
        hand.add(1);
        hand.add(1);
        hand.add(2);

        assertFalse(player.isWin(), "not a winning hand");
    }

    @Test
    void testAnotherplayerinstawin() {
        hand.clear();
        hand.add(1);
        hand.add(1);
        hand.add(1);
        hand.add(1);

        Thread playerThread = new Thread(player);
        playerThread.start();
        try {
            playerThread.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        assertTrue(gameWon.get(),"Game should be won by this point");
        assertEquals(1,playerIDWon.get(),"Winning ID is same as this");
        

        
    }

    
}