import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;

import OutputFiles.OutputFile;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.util.concurrent.TimeUnit;


public class TestOutputFile {
    private OutputFile outputFile;
    private int numOfPlayers;
    private String generatedFolderPath;


    @BeforeEach
    void setUp() {
        numOfPlayers = 4;
        outputFile = new OutputFile(numOfPlayers);

    }

    @Test
    @DisplayName("Testing to see if it creates a real folder")
    void testCreateFolder() throws IOException {
        generatedFolderPath = outputFile.createFolder();
        File folder = new File(generatedFolderPath);

        assertTrue(folder.exists(), "The folder exists after creation");
        assertTrue(folder.isDirectory(), "Should be a directory");

        assertTrue(folder.getName().startsWith("GamePlayed="),"Folder should start with this and then use the time");
    }

    @Test
    @DisplayName("Testing to see if when you create two folders one after the other they have unique names")
    void testFolderUnique() throws IOException, InterruptedException {
        String folder1 = outputFile.createFolder();
        TimeUnit.SECONDS.sleep(2);
        String folder2 = outputFile.createFolder();

        assertNotEquals(folder1, folder2,"Two different timestamps here");
    }

    @Test
    @DisplayName("Testing to make sure output files are made for players when folder is made")
    void testOutputFilesMade() throws IOException {
        generatedFolderPath = outputFile.createFolder();
        File folder = new File(generatedFolderPath);

        outputFile.createOutputFile(folder);

        for (int i=1; i <=numOfPlayers;i++) {
            File playerFile = new File(folder, "player" + i + "_output.txt");
            assertTrue(playerFile.exists(),"File exists");
            assertTrue(playerFile.isFile(),"file is file");
        }
        

    }

    
}
