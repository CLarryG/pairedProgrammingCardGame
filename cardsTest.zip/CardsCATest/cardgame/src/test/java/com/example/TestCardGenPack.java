import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import CardPacks.CardPackGen;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.IOException;
import java.util.List;


public class TestCardGenPack {

    private CardPackGen cardPackGen;
    
    @BeforeEach
    void setUp() {
        int numOfPlayers = 4;
        cardPackGen = new CardPackGen(numOfPlayers);
        
    
    }



    @Test 
    void testCreateFile() throws IOException {
        File createdFile = cardPackGen.createFile();
        assertTrue(createdFile.exists(),"File should be created");
        
        
    }

    @Test
    void testPackGeneration() {
        List<Integer> pack = cardPackGen.getPack();
        
        int expectedCards = 8 * 4;
        assertEquals(expectedCards, pack.size(),"Pack should be correct amount of cards in");
    }
    
}
